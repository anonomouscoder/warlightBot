g++ -std=c++1y -O2 main.cpp Bot.cpp SuperRegion.cpp Region.cpp Parser.cpp
cp ./a.out ../visualizer/a.out
