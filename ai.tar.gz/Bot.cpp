// stl
#include <iostream>
#include <string>
#include <cstdlib>
#include <fstream>
#include <algorithm>
#include <math.h>
//project
#include "Bot.h"

//tools
#include "tools/StringManipulation.h"

Bot::Bot() :
		armiesLeft(0), timebank(0), timePerMove(0), maxRounds(0), parser(this), phase(NONE), state(CONSOLIDATE)
{
	debug.open("debuga.txt", std::fstream::out);
	debug << "debugstarted" << std::endl;
}

Bot::~Bot()
{
	debug.close();
}

void Bot::playGame()
{
	parser.parseInput();
}

void Bot::pickStartingRegion()
{
	// START HERE!

	//sort the superregions by weight
	auto compareFunc = [](std::pair<unsigned,unsigned> a, std::pair<unsigned,unsigned> b) { return a.second < b.second; };
	std::sort ( weightedSuperRegionIndexList.begin(), weightedSuperRegionIndexList.end(), compareFunc);
	
	round = 0;
	debug << "Choosing Regions("<< timebank <<"): " << std::endl;
	unsigned target = 999;
	std::vector<std::pair<unsigned,unsigned>> weights;
	unsigned maxChecks = 10;
	
	for ( unsigned startRegionIndex = 0; 
		  startRegionIndex < std::min((unsigned)startingRegionsreceived.size(),maxChecks); 
 		  ++startRegionIndex)
	{
		Region thisStartRegion = regions[startingRegionsreceived[startRegionIndex]];
		SuperRegion thisStartSuperRegion = superRegions[thisStartRegion.getSuperRegion()];

		unsigned weight = 1000;
		weight -= weightedSuperRegionIndexList[thisStartRegion.getSuperRegion()].second;
		
		debug << "Region "<< startingRegionsreceived[startRegionIndex] <<", weight = " << weight << std::endl;	
		weights.push_back(std::pair<unsigned,unsigned>(startRegionIndex,weight) );
	}
	//sort in reverse order
	auto reversecompareFunc = [](std::pair<unsigned,unsigned> a, std::pair<unsigned,unsigned> b) { return a.second < b.second; };
	std::sort ( weights.begin(), weights.end(), reversecompareFunc);
	target = weights[0].first;
	debug << ".Choosing "<< regions[target].getId()  << " , superregion: " << regions[target].getSuperRegion() << std::endl;
	std::cout << startingRegionsreceived[target] << std::endl;
}

void Bot::placeArmies()
{
	// START HERE!
	round++;
	debug << "Round " << round << std::endl;
	unsigned target = 999;
	debug << "Placing Armies("<< timebank <<"): " << std::endl;
	debug << ".Choosing 2 from: [";
	for ( int i = 0; i < owned.size(); ++i) debug << owned[i] << ",";
	debug << "]" << std::endl;

	std::vector<std::pair<unsigned,unsigned>> weights;

	unsigned maxChecks = 100;
	std::vector<unsigned> unitsNeededList;
	for ( unsigned ownedIndex = 0; 
		  ownedIndex < std::min((unsigned)owned.size(),maxChecks); 
 		  ++ownedIndex)
	{
		Region thisOwnedRegion = regions[owned[ownedIndex]];
		unsigned numberOfNeighbors = thisOwnedRegion.getNbNeighbors();
		bool regionHasEnemy = false;
		bool regionHasNeutral = false;
		unsigned weight = 1;
		unsigned unitsNeeded = 1;
		debug << ".Checking neighbors of " << owned[ownedIndex] << std::endl;
		for ( unsigned l = 0; l < std::min(numberOfNeighbors, maxChecks); ++l)
		{
			//debug << "..l = " << l << ", numberOfNeighbors = " << numberOfNeighbors << std::endl;
			//debug << "..weight of " << owned[ownedIndex] << " : " << weight << std::endl;
			Region thisNeighborRegion = regions[thisOwnedRegion.getNeighbor(l)];
			SuperRegion thisNeighborSuperRegion = superRegions[thisNeighborRegion.getSuperRegion()];
			if (thisNeighborRegion.getOwner() == ENEMY)
			{
				if (!regionHasEnemy) 
				{
					weight += 50;
					regionHasEnemy = true;
				}
				unitsNeeded += thisNeighborRegion.getArmies() * 1000 / 568;
				if ( thisNeighborRegion.getSuperRegion() == thisOwnedRegion.getSuperRegion() )
				{
					weight += thisNeighborSuperRegion.getReward()*100 / thisNeighborSuperRegion.size();
					debug  << "..weight = " << thisNeighborSuperRegion.getReward()*100 / thisNeighborSuperRegion.size();
					debug << "(" << thisNeighborSuperRegion.getReward() 
						  << " / " << thisNeighborSuperRegion.size() << ") ";
				}
			}
			if (thisNeighborRegion.getOwner() == NEUTRAL)
			{
				if (!regionHasNeutral) 
				{
					weight += 100;
					regionHasNeutral = true;
					debug << "+ 100 (neutral) ";
				}
				unitsNeeded += thisNeighborRegion.getArmies() * 1000 / 568;
				if (thisNeighborRegion.getSuperRegion() == thisOwnedRegion.getSuperRegion())
				{
					weight += thisNeighborSuperRegion.getReward()*100 / thisNeighborSuperRegion.size();
					debug  << "..weight = " << thisNeighborSuperRegion.getReward()*100 / thisNeighborSuperRegion.size();
					debug << "(" << thisNeighborSuperRegion.getReward() 
						  << " / " << thisNeighborSuperRegion.size() << ") ";
				}
			}
			
		}
		debug << std::endl << ".done Checking neighbors of " << owned[ownedIndex] << " weight = " << weight << std::endl;
		if (thisOwnedRegion.getArmies() > 50) 
			weight = 1;
		weights.push_back(std::pair<unsigned,unsigned>(ownedIndex,weight) );
		unitsNeededList.push_back(unitsNeeded);
		//std::vector<std::pair<unsigned,unsigned>>::iterator it;
		//debug << ".Size of weights list: " <<  std::distance(weights.begin(),weights.end()) << std::endl;
		//debug << ".Current weights list: [";
		//for (it=weights.begin(); it!=weights.end(); it++)
		//	debug << it->first << ":" << it->second << ", ";
		//debug << "]" << std::endl;
	}
	std::vector<std::pair<unsigned,unsigned>>::iterator it;
	//debug << ".Final weights list: [";
	//for (it=weights.begin(); it!=weights.end(); it++)
	//	debug << it->first << ":" << it->second << ", ";
	//debug << "]" << std::endl;

	auto compareFunc = [](std::pair<unsigned,unsigned> a, std::pair<unsigned,unsigned> b) { return a.second > b.second; };
	std::sort ( weights.begin(), weights.end(), compareFunc);
	debug << ".Sorted weights list: [";
	for (it=weights.begin(); it!=weights.end(); it++)
		debug << it->first << ":" << it->second << ", ";
	debug << "]" << std::endl;
	target = weights[0].first;
	debug << ".Target chosen: " << target << std::endl;


	debug << ".choosing troop sizes: " << std::endl;
	std::vector<unsigned> troops;
	unsigned reserve = armiesLeft;
	for (it=weights.begin(); it!=weights.end(); it++)
	{
		target = it->first;
		unsigned unitsNeeded;
		if (regions[owned[target]].getArmies() > unitsNeededList[target])
			unitsNeeded = 0;
		else
			unitsNeeded = unitsNeededList[target] - regions[owned[target]].getArmies();
		debug << "..region " << owned[target] << " needs " << unitsNeeded << " troops (" << reserve << " left)" << std::endl;
		if (unitsNeeded < reserve)
		{
			troops.push_back(unitsNeeded);
			reserve -= unitsNeeded;
		} else
		{
			troops.push_back(reserve);
			break;
		}
	}
	if (reserve != 0)
	{
		troops[0] += reserve;
	}
	std::vector<std::string> placements;
	for(int i=0;i<troops.size();i++)
	{
		if (troops[i] > 0)
		{
			target = weights[i].first;
			std::stringstream placement;
			placement <<" "<< botName << " place_armies " << owned[target] << " " << troops[i];
			placements.push_back(placement.str());
			addArmies(owned[target], troops[i]);
		}
	}
	std::cout << string::join(placements,',') << std::endl;
	debug << string::join(placements) << std::endl;
}

void Bot::makeMoves()
{
	// START HERE!
	/// Output No moves when you have no time left or do not want to commit any moves.
	// std::cout << "No moves "  << std::endl;
	/// Anatomy of a single move
	//  std::cout << botName << " attack/transfer " << from << " " << to << " "<< armiesMoved;
	/// When outputting multiple moves they must be seperated by a comma
	debug << "Making moves("<< timebank <<")" << std::endl;
	
	std::vector<std::string> moves;
	unsigned maxChecks = 100;
	std::vector<bool> attackedRegions = std::vector<bool>(regions.size(),false);
	for (unsigned ownedIndex = 0; ownedIndex < std::min((unsigned)owned.size(),maxChecks); ++ownedIndex)
	{
		Region thisOwnedRegion = regions[owned[ownedIndex]];
		//if this territory only has 1-4 army, skip it
		if (thisOwnedRegion.getArmies() <= 4)
			continue;
		std::stringstream move;
		debug << ".Looking at region " << owned[ownedIndex] 
			  << ": str= " << thisOwnedRegion.getArmies() 
			  << std::endl;
		unsigned numberOfNeighbors = thisOwnedRegion.getNbNeighbors();
		std::vector<std::pair<unsigned,unsigned>> weightedPossibleMoves;

		unsigned maxNeighborChecks = 100;
		bool hasBadNeighbor = false;
		bool saveForFinalRegionInSuperRegion = false;

		for ( unsigned neighborIndex = 0; neighborIndex < std::min(numberOfNeighbors,maxNeighborChecks); ++neighborIndex)
		{
			unsigned weight = 1;
			Region thisNeighborRegion = regions[thisOwnedRegion.getNeighbor(neighborIndex)];
			debug << "..neighbor " << thisOwnedRegion.getNeighbor(neighborIndex) 
                  << ": str= " << thisNeighborRegion.getArmies() 
                  << std::endl;
			switch(thisNeighborRegion.getOwner())
			{
				case ENEMY:
					debug << "...owned by enemy, weight == 20";
					weight = 20;
				case NEUTRAL: //or enemy
					if( weight != 20)
					{
						debug << "...owned by neutral, weight == 10";
						weight = 10;
					}
					if( thisNeighborRegion.getSuperRegion() == thisOwnedRegion.getSuperRegion() )
					{
						weight += 100;
						debug << ", in same superregion. weight + 100";	
						weight += weightedSuperRegionIndexList[thisNeighborRegion.getSuperRegion()].first;
						debug << " + "+weightedSuperRegionIndexList[thisNeighborRegion.getSuperRegion()].second;

						//count how many regions of this superregion that I don't have
						std::vector<int>::iterator it;
						std::vector<int> regionsOfThisSuperRegion = superRegions[thisNeighborRegion.getSuperRegion()].getRegions();
						int countOfOwnedRegions = 0;
						for( it=regionsOfThisSuperRegion.begin(); it!=regionsOfThisSuperRegion.end(); it++)
						{
							if( regions[*it].getOwner() == ME ) countOfOwnedRegions++;
						}
					
						if( (unsigned)superRegions[thisNeighborRegion.getSuperRegion()].size() - countOfOwnedRegions == 1 )
						{
							debug << ", but this is the last region in this super region, don't move troops from thisOwnedRegion";
							saveForFinalRegionInSuperRegion = true;
						}
					}
					if( (thisNeighborRegion.getArmies())*1000 < (thisOwnedRegion.getArmies()-1)*504  + pow(0.6,(thisOwnedRegion.getArmies()-1)) * 160 )
					{
						weight += 1000;
						debug << ", conquerable. weight + 1000";
						//no need to save, i can kill it
						saveForFinalRegionInSuperRegion = false;
					}
					
					if( attackedRegions[thisNeighborRegion.getId()] )
					{
						debug << ", but this region is already being attacked, so treat it like it's already mine";
						weight = 500;
					}
					debug << std::endl;
					hasBadNeighbor = true;
					break;
				default:
				case ME:
					weight = 500;
					debug << "...owned by me, weight == 500 ";
					if( (thisNeighborRegion.getArmies()-1) > (thisOwnedRegion.getArmies() - 1) )
					{
						weight += 15;
						debug << " + 15 because it's stronger " << std::endl;
					}
					
					break;
			}
			
			weightedPossibleMoves.push_back( std::pair<unsigned,unsigned>(thisOwnedRegion.getNeighbor(neighborIndex),weight) );

		}
		std::vector<std::pair<unsigned,unsigned>>::iterator it;

		//sort the weighted list:
		auto compareFunc = [](std::pair<unsigned,unsigned> a, std::pair<unsigned,unsigned> b) { return a.second > b.second; };
		std::sort ( weightedPossibleMoves.begin(), weightedPossibleMoves.end(), compareFunc);
		debug << ".Sorted weights list: [";
		for (it=weightedPossibleMoves.begin(); it!=weightedPossibleMoves.end(); it++)
			debug << it->first << ":" << it->second << ", ";
		debug << "]" << std::endl;
		
		unsigned target = weightedPossibleMoves[0].first;
		unsigned weight = weightedPossibleMoves[0].second;
		
		//if everyone around me is friendly, allow movements to be above the 500 required weight
		if( !hasBadNeighbor ) weight += 10000;

		// don't add a move unless a good one is found
		if (target != 0 && weight > 500 && !saveForFinalRegionInSuperRegion)
		{
			attackedRegions[target] = true;
			unsigned defenseStr = regions[target].getArmies();
			int luckfactor = -1;
			// approximations...

			if( defenseStr >= 4 ) luckfactor = -3;
			if( defenseStr >= 10 ) luckfactor = 6;
			if( defenseStr >= 13 ) luckfactor = 9;
			if( defenseStr >= 50 ) luckfactor = 32;
			if( defenseStr >= 100 ) luckfactor = 67;
			
			unsigned strengthNeeded = ( defenseStr * 1000 - (luckfactor * 160) ) / 504;
			debug << ". moving " << std::min( strengthNeeded,(unsigned)(thisOwnedRegion.getArmies()-1)) << " to " << target << std::endl;
			move <<" "<< botName << " attack/transfer " << owned[ownedIndex] << " "
					<< target << " "
					<< std::min( strengthNeeded, (unsigned)(thisOwnedRegion.getArmies()-1));
			moves.push_back(move.str());
		}
		debug << ".# of moves saved: " << moves.size() << std::endl;
	}
	if (moves.size() < 1) // if no moves are found, send back no moves
	{
		debug <<".No moves" << std::endl;
		std::cout << "No moves" << std::endl;
	} else 
	{
		debug <<"." << string::join(moves) << std::endl;
		std::cout << string::join(moves) << std::endl;
	}
}

void Bot::addRegion(const unsigned& noRegion, const unsigned& noSuperRegion)
{
	while (regions.size() <= noRegion)
	{
		regions.push_back(Region());
	}
	regions[noRegion] = Region(noRegion, noSuperRegion);
	superRegions[noSuperRegion].addRegion(noRegion);

}
void Bot::addNeighbors(const unsigned& noRegion, const unsigned& neighbors)
{
	regions[noRegion].addNeighbor(neighbors);
	regions[neighbors].addNeighbor(noRegion);
}
void Bot::addWasteland(const unsigned &noRegion)
{
	wastelands.push_back(noRegion);
	unsigned noSuperRegion = regions[noRegion].getSuperRegion();
	weightedSuperRegionIndexList[noSuperRegion].second = superRegions[noSuperRegion].getReward() * 50 / (unsigned)superRegions[noSuperRegion].size();
}
void Bot::addSuperRegion(const unsigned& noSuperRegion, const int&reward)
{
	while (superRegions.size() <= noSuperRegion)
	{
		superRegions.push_back(SuperRegion());
		weightedSuperRegionIndexList.push_back(std::pair<unsigned,unsigned>(noSuperRegion,0));
	}
	superRegions[noSuperRegion] = SuperRegion(reward);
}

void Bot::setBotName(const std::string& name)
{
	botName = name;
}
void Bot::setOpponentBotName(const std::string& name)
{
	opponentBotName = name;
}
void Bot::setArmiesLeft(const int& nbArmies)
{
	armiesLeft = nbArmies;
}
void Bot::setTimebank(const int &newTimebank)
{
	timebank = newTimebank;
}
void Bot::setTimePerMove(const int &newTimePerMove)
{
	timePerMove = newTimePerMove;
}
void Bot::setMaxRounds(const int &newMaxRounds)
{
	maxRounds = newMaxRounds;
}

void Bot::clearStartingRegions()
{
	startingRegionsreceived.clear();
}

void Bot::addStartingRegion(const unsigned& noRegion)
{
	startingRegionsreceived.push_back(noRegion);
}

void Bot::addOpponentStartingRegion(const unsigned& noRegion)
{
	opponentStartingRegions.push_back(noRegion);
}
void Bot::opponentPlacement(const unsigned & noRegion, const int & nbArmies)
{
	// suppress unused variable warnings
	(void) noRegion;
	(void) nbArmies;

	// TODO: STUB
}
void Bot::opponentMovement(const unsigned &noRegion, const unsigned &toRegion, const int &nbArmies)
{
	// suppress unused variable warnings
	(void) noRegion;
	(void) toRegion;
	(void) nbArmies;

	// TODO: STUB
}

void Bot::startDelay(const int& delay)
{
	// suppress unused variable warnings
	(void) delay;
	// TODO: STUB
}
void Bot::setPhase(const Bot::Phase pPhase)
{
	phase = pPhase;
}
void Bot::executeAction()
{
	if (phase == NONE)
		return;
	if (phase == Bot::PICK_STARTING_REGION)
	{
		pickStartingRegion();
	}
	else if (phase == Bot::PLACE_ARMIES)
	{
		placeArmies();
	}
	else if (phase == Bot::ATTACK_TRANSFER)
	{
		makeMoves();
	}
	phase = NONE;
}

void Bot::updateRegion(const unsigned& noRegion, const  std::string& playerName, const int& nbArmies)
{
	Player owner;
	if (playerName == botName)
		owner = ME;
	else if (playerName == opponentBotName)
		owner = ENEMY;
	else
		owner = NEUTRAL;
	regions[noRegion].setArmies(nbArmies);
	regions[noRegion].setOwner(owner);
	if (owner == ME)
		owned.push_back(noRegion);
}
void Bot::addArmies(const unsigned& noRegion, const int& nbArmies)
{
	regions[noRegion].setArmies(regions[noRegion].getArmies() + nbArmies);
}
void Bot::moveArmies(const unsigned& noRegion, const unsigned& toRegion, const int& nbArmies)
{
	if (regions[noRegion].getOwner() == regions[toRegion].getOwner() && regions[noRegion].getArmies() > nbArmies)
	{
		regions[noRegion].setArmies(regions[noRegion].getArmies() - nbArmies);
		regions[toRegion].setArmies(regions[toRegion].getArmies() + nbArmies);
	}
	else if (regions[noRegion].getArmies() > nbArmies)
	{
		regions[noRegion].setArmies(regions[noRegion].getArmies() - nbArmies);
		if (regions[toRegion].getArmies() - std::round(nbArmies * 0.6) <= 0)
		{
			regions[toRegion].setArmies(nbArmies - std::round(regions[toRegion].getArmies() * 0.7));
			regions[toRegion].setOwner(regions[noRegion].getOwner());
		}
		else
		{
			regions[noRegion].setArmies(
					regions[noRegion].getArmies() + nbArmies - std::round(regions[toRegion].getArmies() * 0.7));
			regions[toRegion].setArmies(regions[toRegion].getArmies() - std::round(nbArmies * 0.6));
		}
	}
}

void Bot::resetRegionsOwned()
{
	owned.clear();
}

