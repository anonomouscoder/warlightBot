sh compile_copy.sh
sh ../visualizer/run_see.sh

